import com.alibaba.fastjson.JSONArray;
import com.valor.els.ElsApplication;
import com.valor.els.model.InfluxUserModel;
import com.valor.els.service.ElasticsearchService;
import com.valor.els.tool.ElasticsearchPostTool;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.influxdb.dto.QueryResult;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import com.valor.els.tool.InfluxdbPostTool;

import java.sql.Timestamp;
import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = ElsApplication.class)
public class ElsApplicationTests {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private ElasticsearchService service;

    @Value("${els.influx.username}")
    private String username;//用户名
    @Value("${els.influx.passwd}")
    private String password;//密码
    @Value("${els.influx.connecturl}")
    private String openurl;//连接地址

    @Test
    public void test()
    {
        logger.info(username);
    }

    @Test
    public void testInfluxDb() {
        InfluxdbPostTool influxdbPostTool = InfluxdbPostTool.getTool(username, password, openurl);
        String dbName = "inf";
        String measurement = "type";
        Map<String, String> tags = new HashMap<String, String>();
        Map<String, Object> fields = new HashMap<String, Object>();
        tags.put("id", "4");
        tags.put("name", "Now data");
        fields.put("code", "AS564542");
        fields.put("desc", "queen");
        fields.put("createPosition", "gd");
        influxdbPostTool.insert(dbName, measurement, tags, fields);
    }

    @Test
    public void testInfluxDbQuery() {
        InfluxdbPostTool influxdbPostTool = InfluxdbPostTool.getTool(username, password, openurl);
        QueryResult queryResult = influxdbPostTool.query("select * from type", "inf");
        if (queryResult == null) logger.info("null");
        List<InfluxUserModel> list = new ArrayList<InfluxUserModel>();
        for (QueryResult.Result result : queryResult.getResults()) {
            List<QueryResult.Series> series = result.getSeries();
            for (QueryResult.Series serie : series) {
                List<List<Object>> values = serie.getValues();
                List<String> columns = serie.getColumns();
                for (List<Object> objs : values) {
                    InfluxUserModel model=new InfluxUserModel();
                    BeanWrapperImpl beanWrapper=new BeanWrapperImpl(model);
                    for (int i = 0; i < objs.size(); i++) {
                        beanWrapper.setPropertyValue(columns.get(i),objs.get(i));
                    }
                    list.add(model);
                }
            }
            logger.info("model list:{}", JSONArray.toJSON(list));
        }
    }

    //单条数据插入
    public void elasticSerchInsert()
    {
        ElasticsearchPostTool restportPostTool= ElasticsearchPostTool.getTool(null,null,null);
        IndexRequest request=new IndexRequest("vaindex","vatype","1");
        Map<String,Object> json=new HashMap<>();
        json.put("account",1000.0);
        json.put("mac","ec2c57a10705");
        json.put("name","huwang");
        json.put("reserve_string","i am huwang");
        json.put("reserve_int",12000);
        Map geo=new HashMap();
        geo.put("lat",-47.9167);
        geo.put("lon",-15.7833);
        json.put("location",geo);
        request.source(json);
        restportPostTool.getAsyResponse(request);
    }

    //批量数据插入
    public void elasticsearchBulkInsert()
    {
        ElasticsearchPostTool restportPostTool= ElasticsearchPostTool.getTool(null,null,null);
        BulkRequest bulkRequest=new BulkRequest();
        Random random=new Random();
        Random lonRandom=new Random();
        for(int i=1;i<=20000;i++)
        {
            IndexRequest request=new IndexRequest("vaindex","vatype");
            Map<String,Object> json=new HashMap<>();
            json.put("account",random.nextInt(100000)+1);
            json.put("mac","ec2c57a10705");
            json.put("name","hu,wang "+random.nextInt(20000));
            json.put("timestamp",System.currentTimeMillis()-random.nextInt(604800000));
            Map geo=new HashMap();
            geo.put("lat",(random.nextInt(180)-90)+lonRandom.nextDouble());
            geo.put("lon",(random.nextInt(360)-180)+lonRandom.nextDouble());
            json.put("location",geo);
            request.source(json);
            System.out.println(json);
            bulkRequest.add(request);
        }
        restportPostTool.getAsyResponse(bulkRequest);
    }

    //批量数据刷新
    public void elasticsearchBulkUpdate()
    {
        ElasticsearchPostTool restportPostTool= ElasticsearchPostTool.getTool(null,null,null);
        BulkRequest bulkRequest=new BulkRequest();
        for(int i=1;i<=20000;i++)
        {
            UpdateRequest request=new UpdateRequest("vaindex","vatype",i+"");
            Map<String,Object> json=new HashMap<>();
            json.put("timestamp",new Timestamp(System.currentTimeMillis()));
            request.doc(json);
            bulkRequest.add(request);
        }
        restportPostTool.getAsyResponse(bulkRequest);
    }


    @Test
    public void testEls()
    {
        service.getDataFromDbAndStore();
    }
}
