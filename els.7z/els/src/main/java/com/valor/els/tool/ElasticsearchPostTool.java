package com.valor.els.tool;

import org.apache.http.HttpHost;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Iterator;

public class ElasticsearchPostTool {

    private static ElasticsearchPostTool restportPostTool = null;
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private String HOST;
    private String SCHEME;
    private int PORT;

    private RestHighLevelClient client;
    private RestClientBuilder clientBuilder;
    private HttpHost httpHost;

    public static ElasticsearchPostTool getTool(String host, Integer port, String scheme) {
        if (restportPostTool == null) {
            restportPostTool = new ElasticsearchPostTool();
            restportPostTool.setHOST(host);
            restportPostTool.setPORT(port);
            restportPostTool.setSCHEME(scheme);
            restportPostTool.init();
        } else if (!host.equals(restportPostTool.getHOST()) || port != restportPostTool.getPORT() || !scheme.equals(restportPostTool.getSCHEME())) {
            restportPostTool.setHOST(host);
            restportPostTool.setPORT(port);
            restportPostTool.setSCHEME(scheme);
            restportPostTool.init();
        }
        return restportPostTool;
    }

    public void init() {
        logger.info("ElasticsearchPostTool init,host:{},port:{},scheme:{}", HOST, PORT, SCHEME);
        httpHost = new HttpHost(HOST, PORT, SCHEME);
        clientBuilder = RestClient.builder(httpHost);
        client = new RestHighLevelClient(clientBuilder);
    }

    public void closeClient() {
        try {
            client.close();
        } catch (Exception e) {
            logger.error("elasticsearch close error:{}", e);
        }
    }

    //同步方法获取POST/PUT操作返回值
    public void getSycResponse(Object request) {
        try {
            if (request instanceof IndexRequest) {
                IndexResponse response = client.index((IndexRequest) request);
                if (response.getResult() == DocWriteResponse.Result.CREATED)
                    logger.info("elasticsearch success create");
                else if (response.getResult() == DocWriteResponse.Result.UPDATED)
                    logger.info("elasticsearch success update");
            } else {
                BulkResponse response = client.bulk((BulkRequest) request);
                Iterator<BulkItemResponse> iterator = response.iterator();
                int failTimes = 0;
                int successTimes = 0;
                while (iterator.hasNext()) {
                    BulkItemResponse bulkItemResponse = iterator.next();
                    if (!bulkItemResponse.isFailed())
                        successTimes++;
                    else
                        failTimes++;
                }
                logger.info("elasticsearch success operate item number:{}", successTimes);
                logger.info("elasticsearch fail operate item number:{}", failTimes);
            }
        } catch (Exception e) {
            logger.error("elasticsearch getSycResponse error:{}", e);
        }
    }

    //异步方法获取POST/PUT操作返回值
    public void getAsyResponse(Object request) {
        if (request instanceof IndexRequest) {
            ActionListener<IndexResponse> listener = new ActionListener<IndexResponse>() {
                @Override
                public void onResponse(IndexResponse indexResponse) {
                    if (indexResponse.getResult() == DocWriteResponse.Result.CREATED)
                        logger.info("elasticsearch success create");
                    else if (indexResponse.getResult() == DocWriteResponse.Result.UPDATED)
                        logger.info("elasticsearch success update");
                    closeClient();
                }

                @Override
                public void onFailure(Exception e) {
                    logger.error("elasticsearch fail:{}", e);
                    closeClient();
                }
            };
            client.indexAsync((IndexRequest) request, listener);
        } else if (request instanceof BulkRequest) {
            ActionListener<BulkResponse> listener = new ActionListener<BulkResponse>() {
                @Override
                public void onResponse(BulkResponse bulkResponse) {
                    Iterator<BulkItemResponse> iterator = bulkResponse.iterator();
                    int failTimes = 0;
                    int successTimes = 0;
                    while (iterator.hasNext()) {
                        BulkItemResponse bulkItemResponse = iterator.next();
                        if (!bulkItemResponse.isFailed())
                            successTimes++;
                        else
                            failTimes++;
                    }
                    logger.info("elasticsearch success operate item number:{}", successTimes);
                    logger.info("elasticsearch fail operate item number:{}", failTimes);
                    closeClient();
                }

                @Override
                public void onFailure(Exception e) {
                    logger.error("elasticsearch fail:{}", e);
                    closeClient();
                }
            };
            client.bulkAsync((BulkRequest) request, listener);
        }
    }

    public String getHOST() {
        return HOST;
    }

    public void setHOST(String HOST) {
        this.HOST = HOST;
    }

    public String getSCHEME() {
        return SCHEME;
    }

    public void setSCHEME(String SCHEME) {
        this.SCHEME = SCHEME;
    }

    public int getPORT() {
        return PORT;
    }

    public void setPORT(int PORT) {
        this.PORT = PORT;
    }
}
