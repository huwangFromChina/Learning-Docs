package com.valor.els.service;

import com.valor.els.model.InfluxUserModel;
import com.valor.els.model.ResponseEntity;
import com.valor.els.tool.InfluxdbPostTool;
import org.influxdb.dto.QueryResult;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InfluxDbService {

    @Value("${els.influx.username}")
    private String username;//用户名
    @Value("${els.influx.passwd}")
    private String password;//密码
    @Value("${els.influx.connecturl}")
    private String openurl;//连接地址

    private InfluxdbPostTool influxdbPostTool;

    public ResponseEntity queryUserMess(String sql,String dbName)
    {
        influxdbPostTool=InfluxdbPostTool.getTool(username,password,openurl);
        QueryResult queryResult = influxdbPostTool.query(sql, dbName);
        List<InfluxUserModel> list = new ArrayList<InfluxUserModel>();
        for (QueryResult.Result result : queryResult.getResults()) {
            List<QueryResult.Series> series = result.getSeries();
            for (QueryResult.Series serie : series) {
                List<List<Object>> values = serie.getValues();
                List<String> columns = serie.getColumns();
                for (List<Object> objs : values) {
                    InfluxUserModel model=new InfluxUserModel();
                    BeanWrapperImpl beanWrapper=new BeanWrapperImpl(model);
                    for (int i = 0; i < objs.size(); i++) {
                        beanWrapper.setPropertyValue(columns.get(i),objs.get(i));
                    }
                    list.add(model);
                }
            }
        }
        return ResponseEntity.success(list);
    }
}
