package com.valor.els.tool;

import com.github.davidmoten.geo.GeoHash;
import com.maxmind.db.CHMCache;
import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.record.City;
import com.maxmind.geoip2.record.Country;
import com.maxmind.geoip2.record.Location;
import com.maxmind.geoip2.record.Subdivision;
import com.valor.els.model.GeoIPData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.InetAddress;

/**
 * MaxMind Geo db 下载地址： http://dev.maxmind.com/geoip/geoip2/geolite2/
 */
public class GeoIPTool {
    private static final Logger logger = LoggerFactory.getLogger(GeoIPTool.class);
    private static DatabaseReader reader;
    private static String DEFAULT_GEODB_FILE = "D:/工程数据/GeoLite2-City.mmdb";

    public static void loadGeoIpData() {
        loadGeoIpData(DEFAULT_GEODB_FILE);
    }

    public static void loadGeoIpData(String geoDbFile) {
        try {
            // A File object pointing to your GeoIP2 or GeoLite2 database
            File geodb = new File(geoDbFile);
            if (!geodb.exists()) {
                logger.info("GeoDB[{}] not exist", geoDbFile);
            } else {
                // This creates the DatabaseReader object, which should be reused across
                // lookups.
                reader = new DatabaseReader.Builder(geodb).withCache(new CHMCache()).build();
            }
        } catch (Exception e) {
            logger.error("Load GeoDB[{}] failed! ex[{}]", geoDbFile, e);
        }
    }

    public static GeoIPData getGeoIPData(String ip) {
        if (reader == null) {
            logger.warn("Geo database is not init, please check");
            return null;
        }
        if (ip == null) {
            return null;
        }
        try {
            InetAddress ipAddress = InetAddress.getByName(ip);

            CityResponse response = reader.city(ipAddress);
            if (response == null) {
                logger.error("Can not get geo info by ip[{}]", ip);
                return null;
            }
            GeoIPData geoIPData = new GeoIPData();
            Country country = response.getCountry();
            if (country != null) {
                geoIPData.setCountryCode(country.getIsoCode());// 'US'
            }

            Subdivision subdivision = response.getMostSpecificSubdivision();
            if (subdivision != null) {
                geoIPData.setStateCode(subdivision.getIsoCode()); // 'MN'
            }

            City city = response.getCity();
            if (city != null) {
                geoIPData.setCityName(city.getName()); // 'Minneapolis'
            }
            Location location = response.getLocation();
            if (location != null) {
                try {
                    String geoHash = GeoHash.encodeHash(location.getLatitude(), location.getLongitude());
                    geoIPData.setLatitude(location.getLatitude());
                    geoIPData.setLongitude(location.getLongitude());
                    geoIPData.setGeohash(geoHash);
                } catch (Exception e) {
                    logger.warn("Error in convert geoHash: %s", ip);
                }
            }
            return geoIPData;
        } catch (Exception e) {
            logger.error("Error in getGeoIPData: %s", ip);
            return null;
        }
    }

    public static String getCountry(String ip) {
        if (ip == null || ip.equals("")) {
            return ip;
        }

        if (reader == null) {
            logger.info("GeoDB not Init ip={}", ip);
            return "";
        }

        try {
            InetAddress ipAddress = InetAddress.getByName(ip);
            CityResponse response = reader.city(ipAddress);
            if (response == null) {
                logger.error("Can not get geo info by ip[{}]", ip);
                return null;
            }

            Country country = response.getCountry();
            if (country != null) {
                return country.getIsoCode();// 'US'
            }

        } catch (Exception e) {
            logger.error("Error in getGeoIPData: {}", ip);
            return null;
        }

        return "";
    }
}

