package com.valor.els.service;

import com.valor.els.dao.TestDao;
import com.valor.els.model.ResponseEntity;
import com.valor.els.model.TestModel;
import com.valor.els.tool.ElasticsearchPostTool;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * elasticsearch
 * huwang
 * 2018/4/20
 */
@Service
public class ElasticsearchService {

    private Logger logger= LoggerFactory.getLogger(ElasticsearchService.class);

    @Value("${els.elasticsearch.host}")
    private String host;//地址
    @Value("${els.elasticsearch.port}")
    private Integer port;//端口
    @Value("${els.elasticsearch.scheme}")
    private String scheme;//连接方式

    @Autowired
    private TestDao testDao;

    //解析传递过来的json并存入elasticsearch
    public ResponseEntity translate(String type,String json)
    {
        return null;
    }

    @Scheduled(cron="0 0 1 * * ?") //每天凌晨1点执行一次
    public void getDataFromDbAndStore()
    {
        List<TestModel> models=testDao.getLastMonthDatas();
        logger.info("get Data From Db size:{}",models.size());
        ElasticsearchPostTool elasticsearchPostTool= ElasticsearchPostTool.getTool(host,port,scheme);
        BulkRequest bulkRequest=new BulkRequest();
        for(TestModel model:models)
        {
            IndexRequest request=new IndexRequest("test","test");
            Map<String,Object> json=new HashMap<>();
            json.put("id",model.getId());
            json.put("str",model.getStr());
            json.put("timestamp",model.getDate().getTime());
            request.source(json);
            bulkRequest.add(request);
        }
        elasticsearchPostTool.getSycResponse(bulkRequest);
        elasticsearchPostTool.closeClient();
    }


}
