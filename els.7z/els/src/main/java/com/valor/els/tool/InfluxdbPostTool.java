package com.valor.els.tool;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class InfluxdbPostTool {

    private static InfluxdbPostTool influxdbPostTool = null;
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private String username;//用户名
    private String password;//密码
    private String openurl;//连接地址

    private InfluxDB influxDB;

    public static InfluxdbPostTool getTool(String username, String password, String openurl) {
        if (influxdbPostTool == null) {
            influxdbPostTool = new InfluxdbPostTool();
            influxdbPostTool.setOpenurl(openurl);
            influxdbPostTool.setPassword(password);
            influxdbPostTool.setUsername(username);
            influxdbPostTool.init();
        } else if (!username.equals(influxdbPostTool.getUsername()) || !password.equals(influxdbPostTool.getPassword()) || !openurl.equals(influxdbPostTool.getOpenurl())) {
            influxdbPostTool.setOpenurl(openurl);
            influxdbPostTool.setPassword(password);
            influxdbPostTool.setUsername(username);
            influxdbPostTool.init();
        }
        return influxdbPostTool;
    }

    public void init() {
        logger.info("connect to influx url:{},user:{},password:{}", openurl, username, password);
        influxDB = InfluxDBFactory.connect(openurl, username, password);
    }

    //设置数据保存策略
    //rp策略名 database数据库名 times(23d)数据保存时限(23天) counterpartNum副本个数 DEFAULT表示设为默认的策略
    public void createRetentionPolicy(String dbName, String rpName, String times, Integer counterpartNum) {
        logger.info("create retention policy:{}", rpName);
        String command = String.format("CREATE RETENTION POLICY \"%s\" ON \"%s\" DURATION %s REPLICATION %s DEFAULT",
                rpName, dbName, times, counterpartNum);
        influxDB.query(new Query(command, dbName));
    }

    //插入数据
    public void insert(String dbName, String measurement, Map<String, String> tags, Map<String, Object> fields) {
        logger.info("insert data to influxDb:{}", dbName);
        Point.Builder builder = Point.measurement(measurement);
        builder.tag(tags);
        builder.fields(fields);
        influxDB.write(dbName, "", builder.build());
    }

    //查询
    public QueryResult query(String command,String dbName){
        return influxDB.query(new Query(command, dbName));
    }

    //创建数据库
    public void createDB(String dbName) {
        logger.info("create database:{}", dbName);
        influxDB.createDatabase(dbName);
    }

    //删除数据库
    public void deleteDB(String dbName) {
        logger.info("delete database:{}", dbName);
        influxDB.deleteDatabase(dbName);
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setOpenurl(String openurl) {
        this.openurl = openurl;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getOpenurl() {
        return openurl;
    }
}
