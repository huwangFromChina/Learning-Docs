package com.valor.els;

import com.valor.els.tool.JvmInfoGetTool;

public class Main {
    public static void main(String args[])
    {
        JvmInfoGetTool jvmInfoGetTool=JvmInfoGetTool.getJvmInfoGetTool();
        jvmInfoGetTool.init(10);
        jvmInfoGetTool.start();
    }
}
