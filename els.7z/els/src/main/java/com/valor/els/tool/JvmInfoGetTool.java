package com.valor.els.tool;

import com.valor.els.config.CustomRegistry;
import io.micrometer.core.instrument.Clock;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.jvm.ClassLoaderMetrics;
import io.micrometer.core.instrument.binder.jvm.JvmGcMetrics;
import io.micrometer.core.instrument.binder.jvm.JvmMemoryMetrics;
import io.micrometer.core.instrument.binder.jvm.JvmThreadMetrics;
import io.micrometer.core.instrument.binder.system.ProcessorMetrics;
import io.micrometer.influx.InfluxConfig;

public class JvmInfoGetTool {

    private static JvmInfoGetTool jvmInfoGetTool;
    private InfluxConfig influxConfig;
    private int STEP = 5;//查询间隔时间，默认为5s

    public static JvmInfoGetTool getJvmInfoGetTool() {
        if (jvmInfoGetTool == null) return new JvmInfoGetTool();
        else return jvmInfoGetTool;
    }

    public  void init(){
        init(STEP);
    }
    public void init(Integer step) {
        if (step != null) STEP = step;
        influxConfig = new InfluxConfig() {
            @Override
            public String get(String key) {
                if (key.equals("influx.enabled")) return "true";
                if (key.equals("influx.step")) return "PT" + STEP + "S";
                else return null;
            }
        };
    }


    public void start() {
        MeterRegistry registry = new CustomRegistry(influxConfig, Clock.SYSTEM);
        new ClassLoaderMetrics().bindTo(registry);  //仪表加载和卸载类
        new JvmMemoryMetrics().bindTo(registry);    //仪表缓冲区和内存池利用率
        new JvmGcMetrics().bindTo(registry);        //仪表最大和实时数据大小，升级和分配率，以及GC暂停时间（或CMS的并发阶段时间）
        new ProcessorMetrics().bindTo(registry);    //测量当前的CPU总量和负载平均值
        new JvmThreadMetrics().bindTo(registry);   //测量线程峰值，守护程序线程数和活动线程数
    }
}
