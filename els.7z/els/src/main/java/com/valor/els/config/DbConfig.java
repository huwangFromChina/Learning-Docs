package com.valor.els.config;


import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Properties;

import static java.sql.Connection.TRANSACTION_READ_COMMITTED;

@Configuration
@EnableTransactionManagement
public class DbConfig {

    private static final Logger logger = LoggerFactory.getLogger(DbConfig.class);

    @Value("${els.database.driver:com.mysql.jdbc.Driver}")
    private String driverClassName;

    @Value("${els.database.dialect:org.hibernate.dialect.MySQL5Dialect}")
    private String dialect;

    @Value("${els.database.url}")
    private String url;

    @Value("${els.database.username}")
    private String username;

    @Value("${els.database.password}")
    private String password;

    @Value("${els.database.showSql:false}")
    private String showSql;

    @Value("${els.database.statistics:false}")
    private String generateStatistics;

    @Value("${els.database.auto:update}")
    private String hbm2ddlAuto;

    @Value("${els.database.poolPreparedStatements:true}")
    private String poolPreparedStatements;


    @Value("${els.database.validationQuery:SELECT 1}")
    private String validationQuery;

    @Value("${els.database.connections.initialSize:5}")
    private String initialSize;

    @Value("${els.database.connections.maxActive:5}")
    private String maxActive;

    @Value("${els.database.connections.minIdle:2}")
    private String minIdle;

    @Value("${els.database.connections.maxIdle:10}")
    private String maxIdle;

    @Value("${els.database.connections.maxWait:500}")
    private String maxWait;

    @Value("${els.database.connections.minEvictableIdleTimeMillis:1800000}")
    private String minEvictableIdleTimeMillis;

    @Value("${els.database.connections.timeBetweenEvictionRunsMillis:1800000}")
    private String timeBetweenEvictionRunsMillis;

    @Value("${els.database.connections.numTestsPerEvictionRun:3}")
    private String numTestsPerEvictionRun;

    @Value("${els.database.connections.testOnBorrow:true}")
    private String testOnBorrow;

    @Value("${els.database.connections.testWhileIdle:true}")
    private String testWhileIdle;

    @Value("${els.database.connections.testOnReturn:true}")
    private String testOnReturn;

    @Bean(destroyMethod="close")
    public BasicDataSource dataSource() {
        logger.trace("Create new data source");

        BasicDataSource basicDataSource = new BasicDataSource();
        basicDataSource.setDriverClassName(driverClassName);
        basicDataSource.setUrl(url);
        basicDataSource.setUsername(username);
        basicDataSource.setPassword(password);

        //在返回连接前，是否进行验证。如果使用，必须使用一个SQL SELECT返回至少一行.如果没有配置，连接调用isValid()方法
        basicDataSource.setValidationQuery(validationQuery);
        //启用poolPreparedStatements后，PreparedStatements 和CallableStatements 都会被缓存起来复用，即相同逻辑的SQL可以复用一个游标，这样可以减少创建游标的数量
        basicDataSource.setPoolPreparedStatements(!StringUtils.trimToEmpty(testOnBorrow).equals("") && Boolean.parseBoolean(poolPreparedStatements));
        // 连接池创建的时候，建立的连接数
        basicDataSource.setInitialSize( NumberUtils.toInt(initialSize,5));
        //最大连接数
        basicDataSource.setMaxActive(NumberUtils.toInt(maxActive,5));
        //最小空闲连接
        basicDataSource.setMinIdle(NumberUtils.toInt(minIdle,2));
        // 最大空闲时间。如果一个用户获取一个连接，不用多长时间会被强行收回
        basicDataSource.setMaxIdle(NumberUtils.toInt(maxIdle, 10));
        // 在抛出异常之前,等待连接被回收的最长时间（当没有可用连接时）。设置为-1表示无限等待
        basicDataSource.setMaxWait(NumberUtils.toInt(maxWait,500));
        //连接保持空闲而不被驱逐的最长时间
        basicDataSource.setMinEvictableIdleTimeMillis(NumberUtils.toLong(minEvictableIdleTimeMillis, 1800000));
        //多少毫秒检查一次连接池中空闲的连接
        basicDataSource.setTimeBetweenEvictionRunsMillis(NumberUtils.toLong(timeBetweenEvictionRunsMillis, 1800000));
        //执行空闲连接验证的线程数
        basicDataSource.setNumTestsPerEvictionRun(NumberUtils.toInt(numTestsPerEvictionRun, 3));
        //在从池中获取连接的时候是否验证。如果验证失败，就会放弃这个连接，试图获取另外的连接
        basicDataSource.setTestOnBorrow(!StringUtils.trimToEmpty(testOnBorrow).equals("") && Boolean.parseBoolean(testOnBorrow));
        //空闲连接是否进行验证，如果失败，就会从连接池去除
        basicDataSource.setTestWhileIdle(!StringUtils.trimToEmpty(testWhileIdle).equals("") && Boolean.parseBoolean(testWhileIdle));
        //在返回连接给连接池的时候，是否进行验证
        basicDataSource.setTestOnReturn(!StringUtils.trimToEmpty(testOnReturn).equals("") && Boolean.parseBoolean(testOnReturn));
        //连接池创建的连接的默认的TransactionIsolation状态
        basicDataSource.setDefaultTransactionIsolation(TRANSACTION_READ_COMMITTED);

        logger.info("Connect database:{}",basicDataSource.getUrl());

        return basicDataSource;
    }

    @Bean(destroyMethod="destroy")
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
        sessionFactoryBean.setDataSource(dataSource());
        sessionFactoryBean.setPackagesToScan("com.valor.els");

        Properties props = new Properties();
        props.put("hibernate.dialect", dialect);
        props.put("hibernate.show_sql", StringUtils.trimToEmpty(showSql).equals("")?false:showSql);
        props.put("hibernate.generate_statistics", StringUtils.trimToEmpty(generateStatistics).equals("")?false:generateStatistics);
        props.put("hibernate.hbm2ddl.auto", hbm2ddlAuto);
        props.put("hibernate.connection.isolation", TRANSACTION_READ_COMMITTED);
        props.put("hibernate.use_sql_comments", true);
        props.put("hibernate.cache.use_query_cache", false);
        props.put("hibernate.cache.use_second_level_cache", false);
        props.put("hibernate.connection.CharSet", "utf8");
        props.put("hibernate.connection.characterEncoding", "utf8");
        props.put("hibernate.connection.useUnicode", false);
        props.put("hibernate.autoReconnect", true);
        sessionFactoryBean.setHibernateProperties(props);

        return sessionFactoryBean;
    }

    @Bean
    public PlatformTransactionManager transactionManager(){
        HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory().getObject());
        transactionManager.setDefaultTimeout(30);
        return transactionManager;
    }
}
