package com.valor.els.dao;

import com.valor.els.model.TestModel;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Transactional
@Repository("testDao")
public class TestDao extends HibernateBaseDao {

    public List<TestModel> testModelList() {
        SQLQuery query = currentSession().createSQLQuery("SELECT * FROM test").addScalar("id", IntegerType.INSTANCE).addScalar("str", StringType.INSTANCE);
        return query.list();
    }

    public List<TestModel> getLastWeekDatas() {
        Calendar calendar=Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DATE,-7);
        Date date=calendar.getTime();
        return currentSession().createCriteria(TestModel.class)
                .add(Restrictions.ge("date",date)).list();
    }

    public List<TestModel> getLastMonthDatas() {
        Calendar calendar=Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MONTH,-1);
        Date date=calendar.getTime();
        return currentSession().createCriteria(TestModel.class)
                .add(Restrictions.ge("date",date)).list();
    }
}
