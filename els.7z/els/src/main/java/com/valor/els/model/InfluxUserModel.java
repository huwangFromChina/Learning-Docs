package com.valor.els.model;

public class InfluxUserModel {

    private String code;
    private String createPosition;
    private String desc;
    private String name;
    private int id;
    private String time;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCreatePosition() {
        return createPosition;
    }

    public void setCreatePosition(String createPosition) {
        this.createPosition = createPosition;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
