package com.valor.els.controller;

import com.valor.els.model.ResponseEntity;
import com.valor.els.service.InfluxDbService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("inf")
public class InfluxDbController{

    private Logger logger= LoggerFactory.getLogger(this.getClass());

    @Autowired
    private InfluxDbService service;

    @RequestMapping("lastHourData")
    @ResponseBody
    public ResponseEntity queryLastHourData()
    {
        String sql="select * from type where time>now() - 1h";
        logger.info("accept request lastDayHour,sql:{}",sql);
        return service.queryUserMess(sql,"inf");
    }

    @RequestMapping("lastDayData")
    @ResponseBody
    public ResponseEntity queryLastDayData()
    {
        String sql="select * from type where time>now() - 1d";
        logger.info("accept request lastDayData,sql:{}",sql);
        return service.queryUserMess(sql,"inf");
    }

}
