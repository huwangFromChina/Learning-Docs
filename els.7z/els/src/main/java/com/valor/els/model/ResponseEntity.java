package com.valor.els.model;

public class ResponseEntity {

    private int responseCode;
    private Object responseObj;

    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public Object getResponseObj() {
        return responseObj;
    }

    public void setResponseObj(Object responseObj) {
        this.responseObj = responseObj;
    }

    public ResponseEntity(int responseCode, Object responseObj)
    {
        this.responseCode=responseCode;
        this.responseObj=responseObj;
    }

    public static ResponseEntity success(Object obj)
    {
        return new ResponseEntity(100,obj);
    }

    public static ResponseEntity invalidKey()
    {
        return new ResponseEntity(201,"invalid key");
    }

    public static ResponseEntity emptyKey()
    {
        return new ResponseEntity(202,"empty key");
    }

    public static ResponseEntity rejectParam()
    {
        return new ResponseEntity(203,"unExpect parameter");
    }
}
