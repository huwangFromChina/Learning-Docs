package com.valor.els.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="test")
public class TestModel {
    private int id;
    private String str;
    private Date date;

    @Id
    @Column(name = "id", length = 20)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "str", length = 128)
    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    @Column(name="date")
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
