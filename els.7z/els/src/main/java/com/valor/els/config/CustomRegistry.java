package com.valor.els.config;


import io.micrometer.core.instrument.*;
import io.micrometer.core.instrument.config.NamingConvention;
import io.micrometer.core.instrument.step.StepMeterRegistry;
import io.micrometer.core.instrument.util.DoubleFormat;
import io.micrometer.core.instrument.util.MeterPartition;
import io.micrometer.influx.InfluxConfig;
import io.micrometer.influx.InfluxNamingConvention;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;


public class CustomRegistry extends StepMeterRegistry {
    private final InfluxConfig config;
    private final Logger logger = LoggerFactory.getLogger(CustomRegistry.class);

    public CustomRegistry(InfluxConfig config, Clock clock, ThreadFactory threadFactory) {
        super(config, clock);
        this.config().namingConvention(new InfluxNamingConvention(NamingConvention.snakeCase));
        this.config = config;
        start(threadFactory);
    }

    public CustomRegistry(InfluxConfig config, Clock clock) {
        this(config, clock, Executors.defaultThreadFactory());
    }

    @Override
    protected void publish() {
        try {
            for (List<Meter> batch : MeterPartition.partition(this, config.batchSize())) {
                batch.stream()
                        .forEach(m -> {
                            if (m instanceof Timer) {
                                writeTimer((Timer) m);
                                return;
                            }
                            if (m instanceof DistributionSummary) {
                                writeSummary((DistributionSummary) m);
                                return;
                            }
                            if (m instanceof FunctionTimer) {
                                writeTimer((FunctionTimer) m);
                                return;
                            }
                            if (m instanceof TimeGauge) {
                                writeGauge(m.getId(), ((TimeGauge) m).value(getBaseTimeUnit()));
                                return;
                            }
                            if (m instanceof Gauge) {
                                writeGauge(m.getId(), ((Gauge) m).value());
                                return;
                            }
                            if (m instanceof FunctionCounter) {
                                writeCounter(m.getId(), ((FunctionCounter) m).count());
                                return;
                            }
                            if (m instanceof Counter) {
                                writeCounter(m.getId(), ((Counter) m).count());
                                return;
                            }
                            if (m instanceof LongTaskTimer) {
                                writeLongTaskTimer((LongTaskTimer) m);
                                return;
                            }
                            writeMeter(m);
                        });

            }
        } catch (Throwable e) {
            logger.error("failed to get metrics", e);
        }
    }


    class Field {
        final String key;
        final double value;

        Field(String key, double value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return key + "=" + DoubleFormat.decimalOrNan(value);
        }
    }

    private void writeMeter(Meter m) {
        Stream.Builder<CustomRegistry.Field> fields = Stream.builder();

        for (Measurement measurement : m.measure()) {
            String fieldKey = measurement.getStatistic().toString()
                    .replaceAll("(.)(\\p{Upper})", "$1_$2").toLowerCase();
            fields.add(new CustomRegistry.Field(fieldKey, measurement.getValue()));
        }
        transformToMap(m.getId(), fields.build());
    }

    private void writeLongTaskTimer(LongTaskTimer timer) {
        Stream<CustomRegistry.Field> fields = Stream.of(
                new CustomRegistry.Field("active_tasks", timer.activeTasks()),
                new CustomRegistry.Field("duration", timer.duration(getBaseTimeUnit()))
        );
        transformToMap(timer.getId(), fields);
    }

    private void writeCounter(Meter.Id id, double count) {
        transformToMap(id, Stream.of(new CustomRegistry.Field("value", count)));
    }

    private void writeGauge(Meter.Id id, double value) {
        transformToMap(id, Stream.of(new CustomRegistry.Field("value", value)));
    }

    private void writeTimer(FunctionTimer timer) {
        Stream<CustomRegistry.Field> fields = Stream.of(
                new CustomRegistry.Field("sum", timer.totalTime(getBaseTimeUnit())),
                new CustomRegistry.Field("count", timer.count()),
                new CustomRegistry.Field("mean", timer.mean(getBaseTimeUnit()))
        );

        transformToMap(timer.getId(), fields);
    }

    private void writeTimer(Timer timer) {
        final Stream.Builder<CustomRegistry.Field> fields = Stream.builder();

        fields.add(new CustomRegistry.Field("sum", timer.totalTime(getBaseTimeUnit())));
        fields.add(new CustomRegistry.Field("count", timer.count()));
        fields.add(new CustomRegistry.Field("mean", timer.mean(getBaseTimeUnit())));
        fields.add(new CustomRegistry.Field("upper", timer.max(getBaseTimeUnit())));
        transformToMap(timer.getId(), fields.build());
    }

    private void writeSummary(DistributionSummary summary) {
        final Stream.Builder<CustomRegistry.Field> fields = Stream.builder();

        fields.add(new CustomRegistry.Field("sum", summary.totalAmount()));
        fields.add(new CustomRegistry.Field("count", summary.count()));
        fields.add(new CustomRegistry.Field("mean", summary.mean()));
        fields.add(new CustomRegistry.Field("upper", summary.max()));

        transformToMap(summary.getId(), fields.build());
    }


    @Override
    protected final TimeUnit getBaseTimeUnit() {
        return TimeUnit.MILLISECONDS;
    }


    private void transformToMap(Meter.Id id, Stream<CustomRegistry.Field> fields) {
        Map<String, String> tagMap = new HashMap<>();
        Map<String, Object> fieldMap = new HashMap<>();
        fields.forEach(p -> fieldMap.put(String.valueOf(p.key), p.value));
        getConventionTags(id).stream().forEach(t -> tagMap.put(t.getKey(), t.getValue()));
        String measurement = getConventionName(id);
        //写入influxdb
        logger.info("measurement:{}", measurement);
        logger.info("tags:{}", tagMap);
        logger.info("fields:{}", fieldMap);
    }
}
