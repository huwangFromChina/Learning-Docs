package com.valor.els.controller;

import com.valor.els.model.ResponseEntity;
import com.valor.els.service.ElasticsearchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("els")
public class ElasticsearchController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ElasticsearchService elasticsearchService;

    @Value("${permission.keys}")
    private String keys;
    private String[] permissionKey;

    @RequestMapping(value = "/com/valor/els/send", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity getData(@RequestParam(value = "key") String key,
                                  @RequestParam(value = "type") String type,
                                  @RequestParam(value = "data") String json) {
        if (key == null || "".equals(key)) {
            logger.info("key字段为空");
            return ResponseEntity.emptyKey();
        } else {
            if (!isContainKey(key)) {
                logger.info("key字段不正确：{}", key);
                return ResponseEntity.invalidKey();
            }
            ResponseEntity responseEntity = elasticsearchService.translate(type, json);
            return responseEntity;
        }
    }

    public boolean isContainKey(String key) {
        permissionKey = keys.split(";");
        for (String k : permissionKey)
            if (k.equals(key)) return true;
        return false;
    }
}
